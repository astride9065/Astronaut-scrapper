from flask import Flask, jsonify
import requests
from bs4 import BeautifulSoup

app = Flask(__name__)

@app.route('/')
def home():
    return 'Astronaut Predictor Server is running.'

@app.route('/scrape')
def scrape_data():
    try:
        url = 'https://1win.com.ci/casino/play/100hp_100hpgaming_astronaut'
        headers = {'User-Agent': 'Mozilla/5.0'}
        response = requests.get(url, headers=headers)
        soup = BeautifulSoup(response.text, 'html.parser')

        # Exemple fictif : à ajuster avec les vraies classes HTML du jeu
        data = soup.find_all('div', class_='some-class')
        results = [el.text.strip() for el in data]

        return jsonify({'status': 'success', 'data': results})
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)})